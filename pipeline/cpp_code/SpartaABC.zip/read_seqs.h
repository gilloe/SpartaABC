#ifndef _READ_SEQS
#define _READ_SEQS
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

vector<string> read_fasta_from_file(string filename);


#endif