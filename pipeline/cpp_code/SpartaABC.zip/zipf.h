#ifndef _ZIPF
#define _ZIPF





#endif
