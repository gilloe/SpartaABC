#include "alphabet.h"

alphabet::~alphabet(){}
// this must be here. see Effective c++ page 63 (item 14, constructors, destructors, 
// assignment
